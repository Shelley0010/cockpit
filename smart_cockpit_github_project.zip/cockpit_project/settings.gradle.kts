rootProject.name = "SmartCockpit"
include(":app")
