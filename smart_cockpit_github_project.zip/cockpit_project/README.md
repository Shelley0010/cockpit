# Smart Cockpit Demo
Android Automotive cockpit demo integrating NetEase Cloud Music, Ximalaya and AMap via adapter interfaces.
