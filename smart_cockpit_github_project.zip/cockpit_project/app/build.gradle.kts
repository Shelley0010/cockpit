plugins { id("com.android.application") }
android {
 namespace = "com.example.cockpit"
 compileSdk = 34
 defaultConfig { applicationId = "com.example.cockpit"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
}
dependencies {}
