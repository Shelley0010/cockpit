package com.example.cockpit.podcast
interface XimalayaService {
 fun playAlbum(albumId:String)
}
