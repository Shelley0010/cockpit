package com.example.cockpit.navigation
interface AMapService {
 fun startNavigation(destination:String)
}
