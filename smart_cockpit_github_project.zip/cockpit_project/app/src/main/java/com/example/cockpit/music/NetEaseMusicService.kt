package com.example.cockpit.music
interface NetEaseMusicService {
 fun login(token:String)
 fun play(songId:String)
}
